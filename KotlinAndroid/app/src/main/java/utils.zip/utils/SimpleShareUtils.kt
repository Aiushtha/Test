package utils

import android.app.Application
import android.content.SharedPreferences
import android.provider.Settings
import com.google.gson.Gson
import org.lxz.utils.share.DataShare

fun initSimpleShare(app:Application)=DataShare.init(app)
fun getSimpleShare(): SharedPreferences =DataShare.getInstance().androidShare.settings;

fun Any?.saveAsJsonBeanSelf():Any?= {DataShare.saveJsonObject(this);this}
fun <T> Class<T>.getAsJsonBeanSelf()=DataShare.getJsonObject(this)
fun Any?.saveAsJsonBeanInKey(key:String?):Any?= key.saveAsJsonBean(this)

fun String?.saveInKey(key:String?)= DataShare.put(key,this)
fun Int?.saveInKey(key:String?)= DataShare.put(key,this)
fun Float?.saveInKey(key:String?)= DataShare.put(key,this)
fun Long?.saveKey(key: String?)= DataShare.put(key,this)
fun Boolean?.saveInkey(key:String?)= DataShare.put(key,this)

fun String?.getStoreString():String?= DataShare.getString(this)
fun String?.getStoreInt():Int?= DataShare.getInt(this)
fun String?.getStoreFloat():Float?= DataShare.getFloat(this)
fun String?.getStoreLong():Long?= DataShare.getLong(this)
fun String?.getStoreBoolean():Boolean?= DataShare.getBoolean(this)

fun String?.saveAsJsonBean(value:Any?):Any?=DataShare.saveJsonObject(this,value)
fun <T> String?.getAsJsonBean(cla:Class<T>):Any?=Gson().fromJson<T>(DataShare.getString(this),cla);

fun String?.saveString(value:String?)=DataShare.put(this,value)
fun String?.saveInt(value:Int?)=DataShare.put(this,value)
fun String?.saveFloat(value:Float?)=DataShare.put(this,value)
fun String?.saveBoolean(value:Boolean?)=DataShare.put(this,value)
fun String?.saveLong(value:Long?)=DataShare.put(this,value)


